# [AzureHound Releases](https://github.com/BloodHoundAD/AzureHound/releases)

To get AzureHound, download the appropriate release for your platform [here](https://github.com/BloodHoundAD/AzureHound/releases) or at the link above.